/**
 * Ernesto Massa 
 * 30/03/2007
 */

//Interface remota: PartidaInterface.java

import java.rmi.Remote;
import java.rmi.RemoteException;
                                                                                                                   
/**
 * Interface remota para a partida.
 */
public interface PartidaInterface extends Remote {                                                                                                                   
  /**
   * M�todo invoc�vel remotamente. Note que o m�todo
   * lan�a a exce��o RemoteException.
   */
  public void IncluiJogador(JogadorInterface j) throws RemoteException;
}
