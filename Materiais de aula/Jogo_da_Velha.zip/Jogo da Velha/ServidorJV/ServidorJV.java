
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */
                                                                                                                                                 
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class ServidorJV {

    public static void main (String[] argv) {
        try {
            LocateRegistry.createRegistry(1099);
            Naming.rebind ("JogodaVelha", new JogodaVelhaRemoto("Servidor Iniciado!"));
            System.out.println ("Servidor Pronto!");
        } catch (Exception e) {
            System.out.println ("Servidor falhou: " + e);
        }
    }
}

