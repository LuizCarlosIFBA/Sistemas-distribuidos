
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface JogadorInterface extends Remote { 

	public byte EfetuaLance()throws RemoteException;
	public void RecebeLance(byte casa) throws RemoteException;
    public void Resultado(byte res) throws RemoteException;
    public void RecebeSimbolo(byte jog) throws RemoteException;       
}
