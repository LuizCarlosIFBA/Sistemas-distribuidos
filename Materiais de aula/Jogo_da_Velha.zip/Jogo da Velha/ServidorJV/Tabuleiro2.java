
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

public class Tabuleiro2
{
    private int TB[][] = { {0,0,0}, {0,0,0}, {0,0,0} };
    
    public Tabuleiro2()
    {
        this.Limpa();
    }

    public void Limpa()
    {
        for(int i=0; i<3; i++){for(int j=0; j<3; j++){TB[i][j]=0;}}
    }
    
    
    public boolean Assinala( byte posicao, int c)
    {
        int linha, coluna;

        linha = (int)(((posicao + 2)/3)-1);
        coluna = (posicao - 3*linha)-1;
       
        if(TB[linha][coluna] == 0)
        {
            TB[linha][coluna] = c;
        }
        else
        {
            return false;
        }
        return true;
    }
    
        public byte VerificaFinal (int jog)
    {
        byte resultado = 0;
        int soma = 0;

        for(int i=0; i<3; i++)
        {
            soma = 0;
            for(int j=0; j<3; j++)
            {
                soma = soma + TB[i][j];
                if (soma == 3*jog){resultado=1;}
            }
        }

        for(int j=0; j<3; j++)
        {
            soma = 0;
            for(int i=0; i<3; i++)
            {
                soma = soma + TB[i][j];
                if (soma == 3*jog){resultado=1;}
            }
        }

        if ((TB[0][0]+TB[1][1]+TB[2][2])==3*jog){resultado=1;}
        if ((TB[0][2]+TB[1][1]+TB[2][0])==3*jog){resultado=1;}

        soma = 0;
        for(int j=0; j<3; j++)
        {
            for(int i=0; i<3; i++)
            {
                if (TB[i][j] == 0){soma++;}
            }
        }
        if (soma==0){resultado=2;}
        
        return resultado;
    }
}
