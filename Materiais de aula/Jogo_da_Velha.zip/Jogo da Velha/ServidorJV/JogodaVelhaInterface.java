
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

import java.rmi.Remote;
import java.rmi.RemoteException;
                                                                                                                   
/**
 * Interface remota para a inicializa��o de uma nova partida.
 */
public interface JogodaVelhaInterface extends Remote {                                                                                                                   
  /**
   * M�todos invoc�vis remotamente.
   */
  public PartidaInterface iniciarjogo(JogadorInterface j) throws RemoteException;
}
