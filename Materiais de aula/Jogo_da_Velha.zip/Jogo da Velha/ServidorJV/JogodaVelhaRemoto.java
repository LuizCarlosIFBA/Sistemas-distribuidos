
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.lang.Thread;   

public class JogodaVelhaRemoto extends UnicastRemoteObject implements JogodaVelhaInterface  {
                                                                                                                   
    private String mensagem;
    private PartidaInterface partida;
    private boolean novojogo = true; 
    JogadorInterface j1=null;
    JogadorInterface j2=null;
    byte jogadoresinscritos=0;


    public JogodaVelhaRemoto(String msg) throws RemoteException {
        mensagem = msg;
      }

    
    public PartidaInterface iniciarjogo(JogadorInterface j) throws RemoteException 
    {
            if (novojogo)
            {
                j1=j;
                novojogo=false;
            }
            else 
            {
                    j2=j;
                    novojogo=true;
                    new PartidaRemoto(j1, j2);
            }
            System.out.println ("Incluiu o Jogador.");
            return partida;
    }
}

class PartidaRemoto extends Thread 
{                                                                                 
    private String mensagem;
    private JogadorInterface j1, j2;
    private int jog1=1, jog2=4;
    private byte jogadoresinscritos;
   
    public PartidaRemoto (JogadorInterface jg1, JogadorInterface jg2){
          j1=jg1;
          j2=jg2;

          this.start();
    }

    
    public void run()
    {
        byte lance;
        Tabuleiro2 Tab = new Tabuleiro2();
        
        try{
            j1.RecebeSimbolo((byte)1);
            j2.RecebeSimbolo((byte)2);
        }
        catch(Exception e) {
            System.out.println ("Erro ao receber o Simbolo: " + e);
        }
        
        while(true)
        {
        try{

            byte teste;
            lance = j1.EfetuaLance();
            Tab.Assinala(lance, jog1);
            teste = Tab.VerificaFinal(jog1);
            if (teste==1)
            {
                j1.Resultado((byte)1);
                j2.RecebeLance(lance);
                j2.Resultado((byte)2);
                return;
            }
            else
            {
                if(teste==2)
                {
                 j1.Resultado((byte)3);
                 j2.RecebeLance(lance);                 
                 j2.Resultado((byte)3);
                 return;
                }
            }
            j2.RecebeLance(lance); 
            
            lance = j2.EfetuaLance();
            Tab.Assinala(lance, jog2);
            teste = Tab.VerificaFinal(jog2);
            if (teste==1)
            {
                j1.RecebeLance(lance);
                j1.Resultado((byte)2);
                j2.Resultado((byte)1);
                return;
            }
            else
            {
                if(teste == 2)
                {
                 j1.RecebeLance(lance);
                 j1.Resultado((byte)3);
                 j2.Resultado((byte)3);
                 System.exit(0);
                }
            }
            j1.RecebeLance(lance);          
        }   
        catch(Exception e) {
                System.out.println ("Erro no lance de um jogador: " + e);
        }
        }
    }
}
