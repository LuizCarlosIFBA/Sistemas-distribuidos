
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

import java.rmi.Remote;
import java.rmi.RemoteException;
                                                                                                                   

public interface PartidaInterface extends Remote {                                                                                                                   

  public void IncluiJogador(JogadorInterface j) throws RemoteException;
}
