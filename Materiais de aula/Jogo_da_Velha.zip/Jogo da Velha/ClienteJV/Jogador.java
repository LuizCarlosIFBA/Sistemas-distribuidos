
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */
                                                                                                                   
 
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.lang.*;
import java.io.*;

                                                                                                               
public class Jogador extends UnicastRemoteObject implements JogadorInterface {

    private char meujogador, adversario;
    private Tabuleiro Tab;
    
    public Jogador() throws RemoteException {
    
        System.out.println ("Utilize as teclas de 1 a 9 do teclado reduzido para fazer os seus lances.");        
    }

  	public void RecebeSimbolo(byte jog) throws RemoteException
  	{
            if(jog==1)
            {
                meujogador = 'X';
                adversario = 'O';
            }
            else
            {
                meujogador = 'O';
                adversario = 'X';
            }
            Tab = new Tabuleiro();
  	 }   
  	 
  	public void RecebeLance(byte casa) throws RemoteException
  	{
 	    Tab.Assinala(casa, adversario);
  	 }
  	 
  	public byte EfetuaLance()throws RemoteException
  	{
  	    byte casa = 0;
  	    boolean valido = false;
  	    while (!valido)
  	    {
  	        System.out.print ("Faca o seu Lance:");
  	        casa = (byte)LeInteiro();
 	        
  	        valido = Tab.Assinala(casa, meujogador);
  	     }
  	    return casa;
  	 }
 
  	static int LeInteiro ()
    {
            int i;
            Integer num;

            DataInputStream in = null;
            in = new DataInputStream (System.in);

            try {
                num = new Integer(in.readLine());
                i = num.intValue();

                return i;
            } catch(Exception e){
                return -1;
            }

    }
    
   public void Resultado(byte res) throws RemoteException
   
   {
       if (res==1)
       {
           System.out.println ("Parabens, Voce venceu!");
        }
        else
        {
            if (res==2)
            {
                System.out.println ("Voce perdeu. Melhor sorte na proxima vez!");
            }
            else
            {
                System.out.println ("Ih!! deu Velha!!!");
            }
        }
    }
}
