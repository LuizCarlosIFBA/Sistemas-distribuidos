
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */
                                                                                                                   
 
import java.rmi.Naming;
import java.rmi.RemoteException;

                                                                                                               
public class ClienteJV
{
    
    public static void main (String[] argv) {

        PartidaInterface partida = null;
         
        try {
             JogodaVelhaInterface ServidorJV =
                (JogodaVelhaInterface) Naming.lookup ("//127.0.0.1:1099/JogodaVelha");

              ServidorJV.iniciarjogo(new Jogador());
        }
                    catch (Exception e) {
                System.out.println ("ServidorJV  falhou " + e);
        }
    }

}
  	 



  	

