
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */


import java.rmi.Remote;
import java.rmi.RemoteException;


public interface JogodaVelhaInterface extends Remote {                                                                                                                   

  public PartidaInterface iniciarjogo(JogadorInterface j) throws RemoteException;
}
