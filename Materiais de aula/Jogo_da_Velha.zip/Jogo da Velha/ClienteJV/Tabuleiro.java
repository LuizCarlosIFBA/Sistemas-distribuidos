
/**
 * MAT570 - Fundamentos em Sistemas Distribu�dos.
 * Ernesto Massa 
 * 30/04/2007
 */

public class Tabuleiro
{
    private char TB[][] = { {' ',' ',' '}, {' ',' ',' '}, {' ',' ',' '} };
    
    public Tabuleiro()
    {
        this.Limpa();
        this.Exibe();
    }

    public void Limpa()
    {
        for(int i=0; i<3; i++){for(int j=0; j<3; j++){TB[i][j]=' ';}}
    }
    
    public void Exibe()
    {
        int i;
            System.out.println (" ");       
        for(i=2; i>0; i--)
        {
            System.out.println (TB[i][0] + " | " + TB[i][1] + " | " + TB[i][2]);
            System.out.println ("__________");
        }
        System.out.println (TB[i][0] + " | " + TB[i][1] + " | " + TB[i][2]);
    }

    
    public boolean Assinala( byte posicao, char c)
    {
        int linha, coluna;

        linha = (int)(((posicao + 2)/3)-1);
        coluna = (posicao - 3*linha)-1;
       
        if(TB[linha][coluna]==' ')
        {
            TB[linha][coluna] = c;
        }
        else
        {
            return false;
        }

        this.Exibe();
        return true;
    }

}
